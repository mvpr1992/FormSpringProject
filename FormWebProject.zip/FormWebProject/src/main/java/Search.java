import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Servlet implementation class Report1
 */
@WebServlet("/Search")
public class Search extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Search() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
     	 try {
	     		response.setContentType("text/html");
	    	    PrintWriter out = response.getWriter();
	    	    final Logger logger = Logger.getLogger(Search.class.getName());
	    	    logger.info("in TransactionStatementReport ");
	    	    String id= request.getParameter("id");
	    	    HttpURLConnection conn=null;
	    	    BufferedReader reader=null;
	    	    StringBuilder strBuf = new StringBuilder();  
	    	    String apiUrl = "http://localhost:8085/" + id;
	    	    
	    	    try {
		    	    URL url = new URL(apiUrl);  
		    	    conn = (HttpURLConnection)url.openConnection();  
		    	    conn.setRequestMethod("GET");
		    	    conn.setRequestProperty("Accept", "application/json");
		    	    if(conn.getResponseCode() != 200) {
		    	    	System.out.println("connection error: "+conn.getResponseCode());
		    	    }
		    	    reader = new BufferedReader(new InputStreamReader(conn.getInputStream(),"utf-8"));
		    	    String output = null;  
		    	    while ((output = reader.readLine()) != null)  
		    	        strBuf.append(output);  
	    	   } catch(Exception e) {
		    		   System.out.println(e.getMessage());
		    	   }
	    	   System.out.println("**************");
	    	   System.out.println(strBuf.toString());
	    	   System.out.println("**************");
	    	   
	    	   JSONObject jsonObject = new JSONObject(strBuf.toString());
	    	   
	    	    int Id = jsonObject.getInt("id");
	    	    String firstname = jsonObject.getString("firstName");
	    	    String lastname = jsonObject.getString("lastName");
 				String address = jsonObject.getString("address");
 				
 				out.println("<html><body><p>Id:</p>" + Id +
 						"<p>First Name:</p>" + firstname +
 						"<p>Last Name:</p>" + lastname +
 						"<p>address:</p>" + address +
 						 "</body></html>");
     	 } catch (JSONException e) {
	   			e.printStackTrace();
	   	}  
	}
}