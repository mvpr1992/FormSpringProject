package com.example.FormProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormProjectApplication.class, args);
	}

}
